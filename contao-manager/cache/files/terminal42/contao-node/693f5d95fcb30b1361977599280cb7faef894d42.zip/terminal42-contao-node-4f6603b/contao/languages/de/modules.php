<?php

/*
 * Backend modules
 */
$GLOBALS['TL_LANG']['MOD']['nodes'] = ['Nodes', 'Nodes mit Inhaltselementen erzeugen und verwalten.'];

/*
 * Frontend modules
 */
$GLOBALS['TL_LANG']['FMD']['nodes'] = &$GLOBALS['TL_LANG']['CTE']['nodes'];
