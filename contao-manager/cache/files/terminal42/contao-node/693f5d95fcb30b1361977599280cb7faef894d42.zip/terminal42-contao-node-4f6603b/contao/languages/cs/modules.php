<?php

/*
 * Backend modules
 */
$GLOBALS['TL_LANG']['MOD']['nodes'] = ['Nodes', 'Vytvořit a spravovat nodes s elementy.'];

/*
 * Frontend modules
 */
$GLOBALS['TL_LANG']['FMD']['nodes'] = &$GLOBALS['TL_LANG']['CTE']['nodes'];
