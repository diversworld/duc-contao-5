<?php

declare(strict_types=1);

namespace Terminal42\NotificationCenterBundle\Config;

class FormConfig extends AbstractConfig
{
}
