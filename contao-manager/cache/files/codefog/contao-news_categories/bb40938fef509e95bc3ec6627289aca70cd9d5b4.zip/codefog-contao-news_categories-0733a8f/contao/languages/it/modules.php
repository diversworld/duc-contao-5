<?php

/*
 * News Categories bundle for Contao Open Source CMS.
 *
 * @copyright  Copyright (c) 2024, Codefog
 * @author     Codefog <https://codefog.pl>
 * @license    MIT
 */

/*
 * Front end modules.
 */
$GLOBALS['TL_LANG']['FMD']['newscategories'] = ['Lista categorie news', 'Aggiunge una lista di categorie news alla pagina.'];
