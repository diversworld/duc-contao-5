<?= "<?php\n"; ?>

declare(strict_types=1);

<?= $this->phpdoc; ?>

/**
 * Legends
 */
//$GLOBALS['TL_LANG']['tl_module']['custom_legend'] = '';

/**
 * Fields
 */
//$GLOBALS['TL_LANG']['tl_module']['customField'] = ['', ''];
