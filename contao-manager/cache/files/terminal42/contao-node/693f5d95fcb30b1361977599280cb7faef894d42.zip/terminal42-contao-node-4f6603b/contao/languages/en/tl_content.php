<?php

$GLOBALS['TL_LANG']['tl_content']['nodes'] = ['Nodes', 'Please choose one or more nodes.'];
$GLOBALS['TL_LANG']['tl_content']['nodesWrapper'] = ['Add wrapper element', 'Add a wrapper element to the nodes.'];
