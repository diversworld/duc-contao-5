# News Categories bundle – Documentation

1. [Installation](installation.md)
2. [Configuration](configuration.md)
3. [Frontend modules](frontend-modules.md)
4. [Template adjustments](template-adjustments.md)
5. [News feeds](news-feeds.md)
6. [Multilingual features](multilingual-features.md)
7. [Insert tags](insert-tags.md)
