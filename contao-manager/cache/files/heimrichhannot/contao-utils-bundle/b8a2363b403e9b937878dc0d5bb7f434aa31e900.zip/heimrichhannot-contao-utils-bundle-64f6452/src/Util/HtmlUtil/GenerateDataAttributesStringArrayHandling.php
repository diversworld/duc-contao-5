<?php

namespace HeimrichHannot\UtilsBundle\Util\HtmlUtil;

enum GenerateDataAttributesStringArrayHandling: string
{
    case REDUCE = 'reduce';
    case ENCODE = 'encode';
}
