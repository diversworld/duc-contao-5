<?php

declare(strict_types=1);

namespace Terminal42\NotificationCenterBundle\Exception;

interface ExceptionInterface
{
}
