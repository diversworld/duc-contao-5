<?php

$GLOBALS['TL_LANG']['tl_content']['nodes'] = ['Nodes', 'Vyberte jeden nebo více prvků.'];
$GLOBALS['TL_LANG']['tl_content']['nodesWrapper'] = ['Přidat wrapper', 'Tím bude přidán div kolem vybraného elementu.'];
