# Changelog
All notable changes to this project will be documented in this file.

## [1.0.2] - 2022-11-10
- Fixed: compatibility issues of PageAssetTrait with ServiceSubscriber::getContainer()

## [1.0.1] - 2022-11-09
- Fixed: compatibility of PageAssetTrait with AbstractFrontendModuleController  

## [1.0.0] - 2022-07-18
Initial version