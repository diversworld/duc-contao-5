---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Context**
Contao version:
Bundle version:
PHP version:

**Description**
<!-- Please describe the issue and provide reproduction steps (in an clean contao installation). If you you're reporting an error, please provide the full error message (ideally an screenshot of the error page in dev mode) -->
