<?php

namespace HeimrichHannot\UtilsBundle\Util\UserUtil;

enum UserType
{
    case USER;
    case MEMBER;
}
