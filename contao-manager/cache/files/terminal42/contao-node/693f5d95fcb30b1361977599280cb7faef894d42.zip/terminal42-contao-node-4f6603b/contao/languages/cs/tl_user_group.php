<?php

use Contao\System;

System::loadLanguageFile('tl_user_group');

/*
 * Legends
 */
$GLOBALS['TL_LANG']['tl_user_group']['node_legend'] = &$GLOBALS['TL_LANG']['tl_user']['node_legend'];
