<?php

/*
 * Content elements
 */
$GLOBALS['TL_LANG']['CTE']['nodes'] = ['Nodes', 'Ein oder mehrere Nodes mit Inhaltselementen einbinden.'];

/*
 * Errors
 */
$GLOBALS['TL_LANG']['ERR']['invalidNodes'] = 'Die Nodes vom Typ "Ordner" sind nicht erlaubt: %s';
