<?php

declare(strict_types=1);

namespace Terminal42\NotificationCenterBundle\Exception\BulkyItem;

class InvalidFileItemException extends \InvalidArgumentException
{
}
