<?php

$GLOBALS['TL_LANG']['tl_files']['usage'] = array('Datei-Nutzung', 'Datei-Nutzung');
$GLOBALS['TL_LANG']['tl_files']['nousage'] = array('Ungenutzte Dateien', 'Ungenutzte Dateien');