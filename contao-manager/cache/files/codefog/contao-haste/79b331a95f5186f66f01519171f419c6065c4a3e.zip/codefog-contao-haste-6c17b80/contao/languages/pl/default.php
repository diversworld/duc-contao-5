<?php

/*
 * Miscellaneous
 */
$GLOBALS['TL_LANG']['HST']['advanced_filter'] = 'Zaawansowany filtr:';
